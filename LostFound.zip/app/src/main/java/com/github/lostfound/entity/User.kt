package com.github.lostfound.entity

data class User(
    var id: Int,
    var username: String,
    var name: String,
    var number: String,
    var avatar: String
)