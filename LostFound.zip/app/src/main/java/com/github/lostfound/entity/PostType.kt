package com.github.lostfound.entity

@Suppress("unused")
enum class PostType {
    TYPE_LOST, TYPE_FOUND
}